// splittechniquedesc.h
#ifndef __SPLITTECHNIQUEDESC_H__
#define __SPLITTECHNIQUEDESC_H__

#ifdef _WIN32
#pragma warning(disable:4786)
//debug symbol warning
#endif

class SplitTechniqueDesc
{
public:
  SplitTechniqueDesc() {}
};

#endif
