// splitting.h
#ifndef __SPLITTING_H__
#define __SPLITTING_H__

#include "splittree.h"
#include "splitnode.h"
#include "splitbuilder.h"
#include "splittraversal.h"
#include "splittechniquedesc.h"
#include "splitcompiler.h"
#include "splitcompilercg.h"
#include "splitcompilerhlsl.h"

#endif
