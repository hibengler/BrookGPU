std::string printGatherIntrinsics();
void printGatherIntrinsics (std::ostream &out);
void ComputeGatherIntrinsics (std::string &content,std::string path, std::string file);
