extern void writePng(char* , char * ,int, int);
extern void DrawLine (char * dat, float x, float y, float x2, float y2, int w);
extern void Draw (float4 *dat, float4 datasize, char * pic, int width);
extern void Draw (float4 *dat, int datasize, char * pic, int width);
extern int haupt (int argc, char ** argv);
