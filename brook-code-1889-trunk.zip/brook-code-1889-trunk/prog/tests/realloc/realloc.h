

void streamRealloc1D (::brook::stream &s, int n);
void streamRealloc2D (::brook::stream &s, int n, int m);


