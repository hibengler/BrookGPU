
#ifndef __PMLSEG_H__
#define __PMLSEG_H__

extern int volfire_main(int argc, char* argv[]);

extern int64 start, mid, stop;

#endif
