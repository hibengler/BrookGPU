
#ifndef __BLAS_H__
#define __BLAS_H__

extern void Blas_Time(int length);

#endif
