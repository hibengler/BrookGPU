
#ifndef __SPARSE_H__
#define __SPARSE_H__

extern void SpMatVec_Time(int streamLength);
extern void ConjGrad_Time(int streamLength);

#endif
