#include <brook/brt.hpp>
brook::stream &getW(int k, int N,bool vertical);

