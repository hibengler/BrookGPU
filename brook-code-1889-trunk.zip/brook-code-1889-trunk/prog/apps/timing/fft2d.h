void doFFT(int logN);
void doOptFFT(int logN);
void doFFTW(int logN);
void fft1d(int logN);
