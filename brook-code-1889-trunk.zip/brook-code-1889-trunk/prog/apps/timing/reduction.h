
#ifndef __REDUCTION_H__
#define __REDUCTION_H__

extern void Reduction_Time(int length);

#endif
