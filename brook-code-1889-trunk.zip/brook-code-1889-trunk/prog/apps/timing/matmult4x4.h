// matmult4x4.h

#ifndef __MATMULT_4X4_H__
#define __MATMULT_4X4_H__

#include <brook/brook.hpp>
#include "main.h"

extern void Matmult4x4_1way_Time( int inStreamSize );
extern void Matmult4x4_4way_Time( int inStreamSize );

#endif

