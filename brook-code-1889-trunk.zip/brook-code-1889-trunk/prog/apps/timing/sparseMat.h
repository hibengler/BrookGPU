
#ifndef __SPARSEMAT_H__
#define __SPARSEMAT_H__

extern void SparseMat_Time(int length);

#endif
