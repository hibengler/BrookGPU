// core.hpp
#pragma once

#ifndef __CORE_HPP__
#define __CORE_HPP__

#include "fibble/fibble.hpp"
#include <brook/brt.hpp>

#endif
