static int start,stop;
static int GetTimeMillis() {return 666;}
